FastShein - Flask + SQLite scaffold
==================================

This version uses SQLite so data (orders) is stored in a file `orders.db` inside the project.
This keeps data across restarts of the process on the same server.

Run locally
-----------
1. python -m venv venv
2. source venv/bin/activate  # Linux/macOS
   venv\Scripts\activate     # Windows
3. pip install -r requirements.txt
4. python app.py
5. Open http://127.0.0.1:5000

Deploy to Render.com
--------------------
- Push repo to GitHub.
- On Render: New -> Web Service -> Connect repo.
- Build command: pip install -r requirements.txt
- Start command: gunicorn app:app
- Deploy.

Important note about persistence on hosts:
- SQLite stores data in the `orders.db` file. On many VPS or container hosts the file will persist.
- On some PaaS providers, redeploying or using ephemeral containers can reset files. If you need robust persistence across redeploys, consider using a managed PostgreSQL database and updating `SQLALCHEMY_DATABASE_URI`.
